function psd= psd_function(Ntot,p2)

       psd = abs((1/sqrt(3*Ntot))*fft(p2)).^2;
 

end