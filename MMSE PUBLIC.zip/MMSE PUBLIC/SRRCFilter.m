function g = SRRCFilter(eRx,Nrx,MRx,Ts)
    delay = Nrx*MRx*1/2;
    t = (-delay:delay)/(MRx);
    idx1 = find(t==0);
    denom = (1-(4*eRx*t./Ts).^2);
    idx2 = find(abs(denom) ~= 0);
    idx3 = find(abs(denom) == 0);
    ind1 = find(idx2==idx1);
    ind2 = find(idx3==idx1);
    idx2(ind1)=[];
    idx3(ind2)=[]; 
    g(idx1) = (1/Ts)*(1+eRx*(4/pi-1));
    g(idx2) = (1/Ts)*((((sin((pi*t(idx2)./Ts).*(1-eRx))))+...
              (4*eRx*t(idx2)./Ts).*cos((pi*t(idx2)./Ts).*(1+eRx)))./...
              ((pi*t(idx2)./Ts).*denom(idx2)));
    g(idx3) = (eRx/(Ts*sqrt(2)))*((1+2/pi)*sin(pi/(4*eRx))+(1-2/pi)*cos(pi/(4*eRx)));
    g = g/norm(g);
end