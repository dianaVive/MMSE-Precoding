function h = RcFilter(eTx,Ntx,uTx,Ts)
delay = Ntx*uTx*1/2;
t = (-delay:delay)/(uTx);
denom = (1-(2*eTx*t./Ts).^2);
idx1 = find(abs(denom) ~= 0);
idx2 = find(abs(denom) == 0);
h(idx1) = (1/Ts)*sinc(t(idx1)./Ts).*(cos(pi*eTx*t(idx1)./Ts)./denom(idx1));
h(idx2) = pi/(4*Ts) * sinc(1/(2*eTx));
h = h/norm(h);
end