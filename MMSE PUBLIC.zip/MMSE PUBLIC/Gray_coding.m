function [CmapTableGray,bitsTableGray,SymbolsGray,theta,eta,lambda] = Gray_coding(MRx,Rin,cs_rhoPositive,cs_rhoNegative)

symbols = 1:Rin;      
if (MRx==2)

    theta = 3;   
    lambda = 2; 
    eta = 2^theta;
    
    bitsTable  = Mapping_Bit2R(Rin,[0 1])';
    bitsTableGray = bi2gray(bitsTable);
    
    SuperSymbols  = Mapping_Bit2R(2,symbols)'; 
    CmapTable = codebook_bits(cs_rhoPositive,cs_rhoNegative,SuperSymbols);  
    CmapTable(6,:) = []; % eliminate abrupt zero crossing sequence
    SuperSymbols(6,:)  = [];
    [CmapTableGray,SymbolsGray] = sort_gray(MRx,CmapTable,SuperSymbols);
end
if (MRx==3)
    theta = 2;
    lambda = 1;
    eta = 2^theta;
    
    CmapTableGray = [ones(Rin,1),cs_rhoPositive];      
    bitsTable  = Mapping_Bit2R(theta,[0 1])';
    bitsTableGray = bi2gray(bitsTable);
    SymbolsGray = symbols;
end
    
    
end