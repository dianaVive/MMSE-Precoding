function [Cout_block_Zc_real,Cout_block_Zc_imaginary] = generate_cout_ZC(xbReal,xbImag,theta,bitsTableGray,SymbolsGray,pilotReal,pilotImag,Rin,cs_rhoPositive,cs_rhoNegative,N,Nu,Nr,MRx)
  
  Cout_block_Zc_imaginary =[]; 
  Cout_block_Zc_real =[];
  symbols = 1:Rin;
 

 for i= 1:Nu*Nr
             pilotRealUser = pilotReal(i);
             pilotImagUser = pilotImag(i);
             xbRealUser = xbReal(i,:);
             xbImagUser = xbImag(i,:);
             
             %Generation of the real part of Cout
             Cout_user_Zc_real = Mapping_Function(xbRealUser,theta,bitsTableGray,SymbolsGray,pilotRealUser,symbols,cs_rhoPositive,cs_rhoNegative,N,MRx);          
             Cout_block_Zc_real =[Cout_block_Zc_real;Cout_user_Zc_real'];
             
              
             %Generation of the imaginary part of Cout
             Cout_user_Zc_imaginary = Mapping_Function(xbImagUser,theta,bitsTableGray,SymbolsGray,pilotImagUser,symbols,cs_rhoPositive,cs_rhoNegative,N,MRx);          
             Cout_block_Zc_imaginary =[Cout_block_Zc_imaginary;Cout_user_Zc_imaginary'];      
 end
end





