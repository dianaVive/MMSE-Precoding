function CmapTable = codebook_bits(A,B,SuperSymbols)

CmapTable = [];
   for i = 1: length(SuperSymbols)
        sequenceBits = [];
        AuxiliarPilot = 1;
        rho = AuxiliarPilot;
        for j =1:2
            if (rho == 1) 
                Cs = A; 
            else
                Cs = B;
            end      
            symbol = SuperSymbols(i,j);
            codeword = Cs(symbol,:);
            sequenceBits = [sequenceBits,codeword];
            rho = codeword(end);
        end
        CmapTable = [CmapTable;sequenceBits];
    end
    pilotPositive = ones(length(CmapTable),1);
    CmapTable = [pilotPositive,CmapTable];
end

