function estimated_xb = detectionZC_bits(z,MRx,N,Nu,Nr,var1,bitsTableGray,CmapTableGray,lambda)    

    estimated_xb=[];
    numberSamples = MRx*lambda; %number of samples of zbi
    CmapPositiveRho = CmapTableGray;
    CmapNegativeRho = -CmapTableGray;
    Cdet =[CmapPositiveRho;CmapNegativeRho];
    if (MRx == 2)
        auxVar = N/2;
    end
     if (MRx == 3)
        auxVar = N;
    end
    for k =1:Nu*Nr
       c = 1;
       y = [];
       zk =z(k,:);
       for i = 1:auxVar
           pos = [];
           zbi = zk(c:c+numberSamples);
           hd = (pdist2(zbi,Cdet,'hamming'));
           IndexMD = (find(hd == min(hd)));
           IndexMinimumDistance = IndexMD(1);
           if (IndexMinimumDistance>var1)
               IndexMinimumDistance = IndexMinimumDistance-var1;                         
           end
           y = [y,bitsTableGray(IndexMinimumDistance,:)];
           c =  c+numberSamples;
       end
       estimated_xb = [estimated_xb;y];
    end

end