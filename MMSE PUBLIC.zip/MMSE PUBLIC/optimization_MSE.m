function [Px_optimal,f,powerConstraint,psdMSE] = optimization_MSE(CoutReal,CoutImg,sig,Eo,Ntot,Nt,Nu,Nr,GTx,U,H_eff,GRx_eff,nq)
  
           
    CoutComplex = CoutReal +1j*CoutImg; 
    A = kron(eye(Nt),GTx'*U);                        %Power constraint
    Cn = (sig^2)*eye(Nu*Nr*Ntot*3);                  % Noise covariance matrix
    
    
    ArgumentAuxMatrix = pinv(H_eff'*H_eff + (((trace(GRx_eff*Cn*(GRx_eff')))/Eo)*(A')*A)); 
    Gamma = H_eff*ArgumentAuxMatrix'*(A')*A*ArgumentAuxMatrix*(H_eff');
    
    %Optimal MMSE precoding vetor ----------------------------------------- 
    f = sqrt((CoutComplex'*Gamma*CoutComplex)/Eo);  % Scaling factor
    Px_optimal = (1/f)*ArgumentAuxMatrix*(H_eff')*CoutComplex;
    
    %Check the Power constraint
    powerConstraint= real(Px_optimal'*(A')*A*Px_optimal);
    
    %PSD ------------------------------------------------------------------   
    Px_complex_antenas = reshape(Px_optimal',[nq,Nt])';
    for j = 1:Nt  
         transmitSignal = GTx'*U*Px_complex_antenas(j,:)';
         psdMSE(j,:) = psd_function(Ntot,transmitSignal)';
    end



            
end