function [GRx,GTx,V,U] = Discrete_Filter_Model(g,h,Ntot,M,nq)

%waveform impulse response matrix
v = conv(h,g);
auxiliarVariable = v; 
U = upsample(eye(nq),M);                   
U = U(1:Ntot,:);  % M-fold upsamplig  matrix                                       
if (rem(length(auxiliarVariable),2)==0)
    auxiliarVariable=[auxiliarVariable 0]; 
end
auxv = ((length(auxiliarVariable)-1)/2)+1;
a1 = auxiliarVariable(auxv:auxv+Ntot-1);
V = toeplitz(a1,a1);  

% Discrete received filter Matrix
auxg = ((length(g)-1)/2)+1;
var = auxg-1*Ntot;
g1 = g(auxg:auxg+(Ntot)-1); 
g2 = g(var:auxg-1);
zerosVectorg = [g2(1,1),zeros(1,length(g2)-1)];
Gn = toeplitz(g1,g1);
Gl = toeplitz (g2,zerosVectorg);
GRx = [Gl',Gn,Gl];

% Discrete Transmit filter Matrix
auxh = (length(h)-1)/2+1;
var2 = auxh-Ntot;
h1 = h(auxh:auxh+Ntot-1);
h2 = h(var2:auxh-1);
zerosVectorh = [h2(1,1),zeros(1,length(h2)-1)];
ht1 = toeplitz(h1,h1);
ht2 = toeplitz(h2,zerosVectorh);
GTx = [ht2;ht1;ht2']';

end