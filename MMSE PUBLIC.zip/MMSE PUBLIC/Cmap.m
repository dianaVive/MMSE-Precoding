function [cs_rhoPositive,cs_rhoNegative]=Cmap(MRx)

    M= MRx +1;
    rul = [];
    for i =1:M
        x = i-1;
        y = [ones(1,M-i),(ones(1,x))*-1];
       rul=[rul;y];
    end
    cs_rhoPositive = rul;
    cs_rhoNegative = -rul;
    
end