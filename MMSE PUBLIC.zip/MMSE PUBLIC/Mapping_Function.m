function CoutUserZx = Mapping_Function(xbUser,theta,bitsTableGray,SymbolsGray,pilot,symbols,cs_rhoPositive,cs_rhoNegative,N,MRx) 

    c=1;
    ConcatenateSymbols = []; 
    %first the symbols are generated from the input bit sequence Xb
    if (MRx == 2) 
       for j = 1:N/2
             x = xbUser(c:c+theta-1);
             hd = (pdist2(x,bitsTableGray,'hamming'))';
             Symbolx = SymbolsGray(hd == min(hd),:);
             ConcatenateSymbols = [ConcatenateSymbols,Symbolx];
             c = c+theta;
       end
    end
   if (MRx == 3)
       for j = 1:N
         x = xbUser(c:c+2-1);
         hd = (pdist2(x,bitsTableGray,'hamming'))';
         Symbolx = SymbolsGray(hd == min(hd));
         ConcatenateSymbols = [ConcatenateSymbols,Symbolx];
         c = c+2;
       end
   end
   SymbolSequence = [pilot,ConcatenateSymbols];
    
 % The mapped sequence Cout is generated-------------------------------------------------
    rhoBegin = pilot;
    rho = rhoBegin; % to code the first symbol
    sequenceSamples = [];
    for i = 2:(N+1)
        if (rho == 1) 
            csi = cs_rhoPositive;
        else
            csi = cs_rhoNegative;
        end
        codewordSymbol = csi((SymbolSequence(i) == symbols),:);
        sequenceSamples = [sequenceSamples,codewordSymbol];
        rho = sequenceSamples(end);
    end
    CoutUserZx= [pilot,sequenceSamples];  % Here the sequence Cout is generated per User
end