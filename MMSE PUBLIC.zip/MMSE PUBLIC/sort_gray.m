function [AbG,XsymG] = sort_gray(MRx,Ab,Xsymb)

    [fil col] = size(Xsymb);
    z = [];
    vx = 1:1:fil;
    in = 1;
    p = 2*MRx+1;
    NsA = [];
    x = Ab(1,:);
    symN = [];
    for i = 1:fil-1
        nin =2*MRx+1;
        vx(in) = [];
        for j = 1:length(vx)
            m = vx(j);
            y = Ab(m,:);
            n = p-length(find(x==y));
            if (n<nin)
               z = vx(j);
               nin = n;
               in = j;
            end
        end
        q = Xsymb(z,:);
        symN = [symN;q];
        x = Ab(z,:);
        NsA = [NsA;x];
    end
    %---------------------------------------------------------------------------
    symN = [Xsymb(1,:);symN];
    NsA = [Ab(1,:);NsA];
    AbG = NsA;
    BbG = -AbG;
    ABbG = [AbG;BbG];
    XsymG = symN;
end




