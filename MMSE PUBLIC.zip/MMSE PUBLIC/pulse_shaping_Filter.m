function[GRx,GTx,V,U]=pulse_shaping_Filter(eTx,eRx,Nrx,Ntx,MRx,MTx,M,Ntot,nq,Ts)
uTx = MTx*M;
h = RcFilter(eTx,Ntx,uTx,Ts);                              
g = SRRCFilter(eRx,Nrx,MRx,Ts);
[GRx,GTx,V,U] = Discrete_Filter_Model(g,h,Ntot,M,nq);
end