%% Main
% PUC RIO
% Diana Marcela Viveros Melo PhD student
% diana@cetuc.puc-rio.br 
% MMSE precoding for "ZERO-CROSSING PRECODING WITH MMSE CRITERION FOR CHANNELS
% WITH 1-BIT QUANTIZATION AND OVERSAMPLING"
clear 
clc

%% Setting parameters
SNR_dB = -10:2:30; %signal-to-noise-ratio in dB
SNR = 10.^(SNR_dB/10); %signal-to-noise-ratio
Ntx = 2000; % length of the transmit filter - Tx                                            
Nrx = 2000;  %length of the receive filter  - Rx
eTx = 0.22;  %roll-off factor Rx 
eRx = 0.22;  %roll-off factor Tx                                         
MTx = 2; % FTN signaling rate factor
MRx = 2;  % %oversampling factor                                             
M = MRx/MTx; %relation between the different sampling rate domains
Rin = MRx+1; % Input cardinality
N = 30; % Number of Nyquist interval
Tb = N*Rin/2; % number of transmit bits                                     
nq = MTx*N+1;   % length of the precoding vector                                   
Ntot = MRx*N+1;  % length of the received vector z per user k   
Nt = 8; % Number of transmit antennas
Nr = 1; % Number of receive antennas                                                 
Nu = 2;  % Number of users
T = 1;  %Symbol duration
Ts = 1; %Filter design parameter
Eo = 1; %Total transmit Energy
Wtx = (1 + eTx)/T; % Bandwidth
channelRealizations = 200;
psdTransmitSignal = [];

%% Filter Response
[GRx,GTx,V,U] = pulse_shaping_Filter(eTx,eRx,Nrx,Ntx,MRx,MTx,M,Ntot,nq,Ts);

%% TI ZX codebook
[cs_rhoPositive,cs_rhoNegative]=Cmap(MRx);
[CmapTableGray,bitsTableGray,SymbolsGray,theta,eta,lambda] = Gray_coding(MRx,Rin,cs_rhoPositive,cs_rhoNegative);

%% Realizations
for iter =1:channelRealizations
    pause(0.01) % Do something important 
    progressbar(iter/channelRealizations) % Update figure
    %Source bits ------------------------------------------------
    xbReal = randi([0 1],Nr*Nu,Tb);
    xbImag = randi([0 1],Nr*Nu,Tb);  
    pilotReal = randsample([-1 1],Nu*Nr,1);
    pilotImag = randsample([-1 1],Nu*Nr,1);
    
    %TI ZX Modulation -------------------------------------------
    [CoutReal,CoutImg] = generate_cout_ZC(xbReal,xbImag,theta,bitsTableGray,SymbolsGray,pilotReal,pilotImag,Rin,cs_rhoPositive,cs_rhoNegative,N,Nu,Nr,MRx);
     
    %channel-----------------------------------------------------
    H = [];
    for ch = 1:Nu
        Huser = (sqrt(1/2)*(randn(Nr,Nt)+1j*randn(Nr,Nt)));
        H =[H;Huser];         
    end
    H_eff = (kron(H,eye(Ntot)))*(kron(eye(Nt),V*U)); % efective channel
    GRx_eff = (kron(eye(Nu*Nr),GRx)); %efective receive filter
    
    for iSNR =1:length(SNR)
        
        %noise ---------------------------------------------------
        sig = sqrt(Eo*trace(H*H')/(N*Nt*Nu*Nr*SNR(iSNR)*Wtx)); %noise variance
        noise = (sig/sqrt(2))*(randn(Nu*Nr*3*Ntot,1)+1j*randn(Nu*Nr*3*Ntot,1)); 
        
        %MMSE Precoder -----------------------------------------
        [Px_optimal,f,powerConstraint,psdMSE] = optimization_MSE(CoutReal,CoutImg,sig,Eo,Ntot,Nt,Nu,Nr,GTx,U,H_eff,GRx_eff,nq);
        psdTransmitSignal = [psdTransmitSignal;psdMSE];
        
        %Receiver -------------------------------------------------
        y = H_eff*Px_optimal + GRx_eff*noise;
        zReal = sign(real(y)); % Quantizing the real part of y
        zImag = sign(imag(y)); % Quantizing the imaginary part of y
        zReal_Users = reshape(zReal',[Ntot,Nu*Nr])';
        zImag_Users = reshape(zImag',[Ntot,Nu*Nr])';
        
        % TI ZX detection -----------------------------------------
        estimated_xbReal = detectionZC_bits(zReal_Users,MRx,N,Nu,Nr,eta,bitsTableGray,CmapTableGray,lambda); 
        estimated_xbImag = detectionZC_bits(zImag_Users,MRx,N,Nu,Nr,eta,bitsTableGray,CmapTableGray,lambda); 
        
        %Cost Function
        J_SNR(iSNR) = cost_function(f,H_eff,CoutReal,CoutImg,sig,Nu,Nr,Ntot,GRx_eff,Px_optimal);

        
        % BER ----------------------------------------------------
        BER_xbReal = biterr(estimated_xbReal,xbReal);
        BER_xbImag = biterr(estimated_xbImag,xbImag);
        BER_SNR(iSNR) = BER_xbReal+BER_xbImag;
    end
    
    BER_Realizations(iter,:)= BER_SNR;
    J_realizations(iter,:) = J_SNR;   
end
BER = mean(BER_Realizations)/(2*Tb*Nu*Nr);
J = mean(J_realizations)/(MRx*N);

%% Plot

figure(1)
semilogy(SNR_dB,BER,'g','LineWidth',2.0);
xlabel('SNR dB');
ylabel('BER');
btitle= horzcat('Bit error rate',' MRx = ',num2str(MRx),', MTx = ',num2str(MTx));
title(btitle);
legend('MMSE Precoder');
grid;

figure(2)
semilogy(SNR_dB,J,'m'); 
xlabel('SNR dB');
ylabel('MSE');
atitle= horzcat('Cost function',' MRx = ',num2str(MRx),', MTx = ',num2str(MTx));
title(atitle);
grid;




