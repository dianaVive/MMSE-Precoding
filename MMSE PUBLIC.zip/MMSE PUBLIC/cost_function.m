function J = cost_function(f,H_eff,CoutReal,CoutImg,sig,Nu,Nr,Ntot,GRx_eff,Px_Optimal)
    CoutComplex = CoutReal +1j*CoutImg; 
    Cn = (sig^2)*eye(Nu*Nr*Ntot*3);
    J = real(norm(f*H_eff*Px_Optimal-CoutComplex,'fro')^2 + f^2*trace(GRx_eff*Cn*GRx_eff'));    
end